import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { FaSignOutAlt, FaAngleDown, FaUser, FaCog } from 'react-icons/fa';
import '../styles/header.css';

const Header = ({ onToggleSidebar }) => {
    const navigate = useNavigate();
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const toggleDropdown = () => {
        setIsDropdownOpen(!isDropdownOpen);
    };

    const handleLogout = () => {
        // Clear auth data
        localStorage.removeItem('token');
        localStorage.removeItem('user');

        // Redirect to login
        navigate('/login');
    };

    useEffect(() => {
        const fetchUserData = async () => {
            try {
                setLoading(true);

                // Get user from localStorage
                const userStr = localStorage.getItem('user');
                if (!userStr) {
                    throw new Error('User data not found');
                }

                const userData = JSON.parse(userStr);

                // If we need to fetch more user details from the API
                if (userData.email) {
                    try {
                        const response = await fetch(`http://localhost:5000/api/auth/user/${userData.email}`, {
                            headers: {
                                'Authorization': `Bearer ${localStorage.getItem('token')}`
                            }
                        });

                        if (!response.ok) {
                            throw new Error('Failed to fetch user details');
                        }

                        const data = await response.json();
                        setUser(data.user);
                    } catch (apiError) {
                        console.error('API Error:', apiError);
                        // Fallback to using the stored user data
                        setUser(userData);
                    }
                } else {
                    setUser(userData);
                }

                setError(null);
            } catch (err) {
                console.error('Error loading user data:', err);
                setError('Failed to load user data');
            } finally {
                setLoading(false);
            }
        };

        fetchUserData();
    }, []);

    if (loading) {
        return (
            <div className="header">
                <button className="toggle-btn" onClick={onToggleSidebar}>
                    ☰
                </button>
                <div className="loading-indicator">Loading user data...</div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="header">
                <button className="toggle-btn" onClick={onToggleSidebar}>
                    ☰
                </button>
                <div className="error-indicator">
                    {error}
                    <button onClick={() => window.location.reload()}>Retry</button>
                </div>
            </div>
        );
    }

    return (
        <div className="header">
            <button className="toggle-btn" onClick={onToggleSidebar}>
                ☰
            </button>

            <div className="profile">
                <div className="profile-info" onClick={toggleDropdown}>
                    <img
                        src={user?.avatar || "/profile.png"}
                        alt="Profile"
                        className="profile-pic"
                    />
                    <span className="username">{user?.name || 'User'}</span>
                    <FaAngleDown className={`dropdown-icon ${isDropdownOpen ? 'open' : ''}`} />
                </div>

                {isDropdownOpen && (
                    <ul className="profile-dropdown">
                        <li>
                            <Link to="/dashboard/profile" onClick={() => setIsDropdownOpen(false)}>
                                <FaUser /> Profile
                            </Link>
                        </li>
                        <li>
                            <Link to="/dashboard/settings" onClick={() => setIsDropdownOpen(false)}>
                                <FaCog /> Settings
                            </Link>
                        </li>
                        <li onClick={handleLogout}>
                            <FaSignOutAlt /> Logout
                        </li>
                    </ul>
                )}
            </div>
        </div>
    );
}

export default Header;
