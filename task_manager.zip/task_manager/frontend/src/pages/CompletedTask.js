import React, { useState, useEffect } from "react";
import Sidebar from "./DashboardSlideBar";
import Header from "./DashboardHeader";
import "../styles/CompletedTask.css";
import { useNavigate } from "react-router-dom";
import { fetchCompletedTasks, deleteTask, isTokenValid, updateTask } from "../utils/api";

const CompletedTasks = () => {
  const navigate = useNavigate();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Check if user is authenticated
    if (!isTokenValid()) {
      navigate('/login');
      return;
    }

    // Fetch completed tasks
    const loadTasks = async () => {
      try {
        setLoading(true);
        const data = await fetchCompletedTasks();
        setTasks(data);
        setError(null);
      } catch (err) {
        console.error('Failed to fetch completed tasks:', err);
        setError('Failed to load tasks. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    loadTasks();
  }, [navigate]);

  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleDelete = async (taskId) => {
    if (window.confirm('Are you sure you want to delete this task?')) {
      try {
        await deleteTask(taskId);
        setTasks(tasks.filter(task => task.id !== taskId));
        alert('Task deleted successfully');
      } catch (err) {
        console.error('Failed to delete task:', err);
        alert('Failed to delete task. Please try again.');
      }
    }
  };

  const handleStatusChange = async (taskId, newStatus) => {
    try {
      await updateTask(taskId, { status: newStatus });

      if (newStatus !== 'Completed') {
        // Remove from completed tasks list if status is changed
        setTasks(tasks.filter(task => task.id !== taskId));
      } else {
        // Update the task in the list
        setTasks(tasks.map(task =>
          task.id === taskId ? { ...task, status: newStatus } : task
        ));
      }

      alert(`Task marked as ${newStatus}`);
    } catch (err) {
      console.error('Failed to update task status:', err);
      alert('Failed to update task. Please try again.');
    }
  };

  return (
    <div className={`dashboard ${isSidebarCollapsed ? "collapsed" : ""}`}>
      <Sidebar isCollapsed={isSidebarCollapsed} />
      <div className="main-content">
        <Header onToggleSidebar={toggleSidebar} />

          <div className="table-section">
            <h3>Completed Tasks</h3>

            {loading ? (
              <p>Loading tasks...</p>
            ) : error ? (
              <p className="error-message">{error}</p>
            ) : tasks.length === 0 ? (
              <p>No completed tasks found.</p>
            ) : (
              <table>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Task Name</th>
                    <th>Description</th>
                    <th>Status</th>
                    <th>Due Date</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {tasks.map((task, index) => (
                    <tr key={task.id}>
                      <td>{index + 1}</td>
                      <td>{task.title}</td>
                      <td>{task.description}</td>
                      <td>
                        <span className="status-badge status-completed">
                          {task.status}
                        </span>
                      </td>
                      <td>{new Date(task.due_date).toLocaleDateString()}</td>
                      <td className="action-buttons">
                        <select
                          onChange={(e) => handleStatusChange(task.id, e.target.value)}
                          value={task.status}
                        >
                          <option value="Pending">Pending</option>
                          <option value="In Progress">In Progress</option>
                          <option value="Completed">Completed</option>
                        </select>
                        <button onClick={() => handleDelete(task.id)}>Delete</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>

  );
};

export default CompletedTasks;
