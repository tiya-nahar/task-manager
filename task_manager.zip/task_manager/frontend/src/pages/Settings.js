import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Sidebar from "./DashboardSlideBar";
import Header from "./DashboardHeader";
import "../styles/Settings.css";
import { isTokenValid } from "../utils/api";

const Settings = () => {
  const navigate = useNavigate();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState("");
  
  // Settings state
  const [settings, setSettings] = useState({
    notifications: {
      email: true,
      push: false,
      taskReminders: true,
      updates: false
    },
    appearance: {
      theme: "light",
      fontSize: "medium",
      compactView: false
    },
    privacy: {
      showTasksToOthers: true,
      allowComments: true
    }
  });

  useEffect(() => {
    // Check if user is authenticated
    if (!isTokenValid()) {
      navigate('/login');
      return;
    }
    
    // Load settings from localStorage if available
    const savedSettings = localStorage.getItem('userSettings');
    if (savedSettings) {
      try {
        setSettings(JSON.parse(savedSettings));
      } catch (err) {
        console.error('Error parsing saved settings:', err);
      }
    }
  }, [navigate]);

  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleNotificationChange = (e) => {
    const { name, checked } = e.target;
    setSettings({
      ...settings,
      notifications: {
        ...settings.notifications,
        [name]: checked
      }
    });
  };

  const handleAppearanceChange = (e) => {
    const { name, value, type, checked } = e.target;
    setSettings({
      ...settings,
      appearance: {
        ...settings.appearance,
        [name]: type === 'checkbox' ? checked : value
      }
    });
  };

  const handlePrivacyChange = (e) => {
    const { name, checked } = e.target;
    setSettings({
      ...settings,
      privacy: {
        ...settings.privacy,
        [name]: checked
      }
    });
  };

  const saveSettings = () => {
    setLoading(true);
    setError(null);
    setSuccessMessage("");
    
    try {
      // Save settings to localStorage
      localStorage.setItem('userSettings', JSON.stringify(settings));
      
      // Here you would typically also save to the backend
      // For now, we'll just simulate a delay
      setTimeout(() => {
        setSuccessMessage("Settings saved successfully!");
        setLoading(false);
      }, 800);
    } catch (err) {
      console.error('Error saving settings:', err);
      setError("Failed to save settings");
      setLoading(false);
    }
  };

  const resetSettings = () => {
    if (window.confirm("Are you sure you want to reset all settings to default?")) {
      const defaultSettings = {
        notifications: {
          email: true,
          push: false,
          taskReminders: true,
          updates: false
        },
        appearance: {
          theme: "light",
          fontSize: "medium",
          compactView: false
        },
        privacy: {
          showTasksToOthers: true,
          allowComments: true
        }
      };
      
      setSettings(defaultSettings);
      localStorage.setItem('userSettings', JSON.stringify(defaultSettings));
      setSuccessMessage("Settings reset to default");
    }
  };

  return (
    <div className={`dashboard ${isSidebarCollapsed ? "collapsed" : ""}`}>
      <Sidebar isCollapsed={isSidebarCollapsed} />
      <div className="main-content">
        <Header onToggleSidebar={toggleSidebar} />
        
        <div className="settings-container">
          <div className="settings-header">
            <h2>Settings</h2>
            <div className="settings-actions">
              <button 
                className="reset-button" 
                onClick={resetSettings}
              >
                Reset to Default
              </button>
              <button 
                className="save-button" 
                onClick={saveSettings}
                disabled={loading}
              >
                {loading ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </div>
          
          {error && <div className="error-message">{error}</div>}
          {successMessage && <div className="success-message">{successMessage}</div>}
          
          <div className="settings-content">
            <div className="settings-section">
              <h3>Notifications</h3>
              <div className="settings-option">
                <label>
                  <input
                    type="checkbox"
                    name="email"
                    checked={settings.notifications.email}
                    onChange={handleNotificationChange}
                  />
                  Email Notifications
                </label>
                <span className="option-description">Receive task updates via email</span>
              </div>
              
              <div className="settings-option">
                <label>
                  <input
                    type="checkbox"
                    name="push"
                    checked={settings.notifications.push}
                    onChange={handleNotificationChange}
                  />
                  Push Notifications
                </label>
                <span className="option-description">Receive notifications in your browser</span>
              </div>
              
              <div className="settings-option">
                <label>
                  <input
                    type="checkbox"
                    name="taskReminders"
                    checked={settings.notifications.taskReminders}
                    onChange={handleNotificationChange}
                  />
                  Task Reminders
                </label>
                <span className="option-description">Get reminders for upcoming tasks</span>
              </div>
              
              <div className="settings-option">
                <label>
                  <input
                    type="checkbox"
                    name="updates"
                    checked={settings.notifications.updates}
                    onChange={handleNotificationChange}
                  />
                  Product Updates
                </label>
                <span className="option-description">Receive updates about new features</span>
              </div>
            </div>
            
            <div className="settings-section">
              <h3>Appearance</h3>
              <div className="settings-option">
                <label>Theme</label>
                <select
                  name="theme"
                  value={settings.appearance.theme}
                  onChange={handleAppearanceChange}
                >
                  <option value="light">Light</option>
                  <option value="dark">Dark</option>
                  <option value="system">System Default</option>
                </select>
              </div>
              
              <div className="settings-option">
                <label>Font Size</label>
                <select
                  name="fontSize"
                  value={settings.appearance.fontSize}
                  onChange={handleAppearanceChange}
                >
                  <option value="small">Small</option>
                  <option value="medium">Medium</option>
                  <option value="large">Large</option>
                </select>
              </div>
              
              <div className="settings-option">
                <label>
                  <input
                    type="checkbox"
                    name="compactView"
                    checked={settings.appearance.compactView}
                    onChange={handleAppearanceChange}
                  />
                  Compact View
                </label>
                <span className="option-description">Show more items per page</span>
              </div>
            </div>
            
            <div className="settings-section">
              <h3>Privacy</h3>
              <div className="settings-option">
                <label>
                  <input
                    type="checkbox"
                    name="showTasksToOthers"
                    checked={settings.privacy.showTasksToOthers}
                    onChange={handlePrivacyChange}
                  />
                  Show My Tasks to Team Members
                </label>
                <span className="option-description">Allow others to see your tasks</span>
              </div>
              
              <div className="settings-option">
                <label>
                  <input
                    type="checkbox"
                    name="allowComments"
                    checked={settings.privacy.allowComments}
                    onChange={handlePrivacyChange}
                  />
                  Allow Comments on Tasks
                </label>
                <span className="option-description">Let others comment on your tasks</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
