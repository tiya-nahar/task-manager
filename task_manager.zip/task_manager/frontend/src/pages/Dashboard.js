import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Sidebar from "./DashboardSlideBar";
import Header from "./DashboardHeader";
import "../styles/Dashboard.css";
import { fetchUserTasks, fetchCompletedTasks, fetchPendingTasks, deleteTask, updateTask } from "../utils/api";

const Dashboard = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [tasks, setTasks] = useState([]);
  const [completedTasks, setCompletedTasks] = useState([]);
  const [pendingTasks, setPendingTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        setLoading(true);

        // Fetch all task data in parallel
        const [allTasksData, completedTasksData, pendingTasksData] = await Promise.all([
          fetchUserTasks(),
          fetchCompletedTasks(),
          fetchPendingTasks()
        ]);

        setTasks(allTasksData);
        setCompletedTasks(completedTasksData);
        setPendingTasks(pendingTasksData);
        setError(null);
      } catch (err) {
        console.error('Failed to fetch dashboard data:', err);
        setError('Failed to load dashboard data. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    loadDashboardData();
  }, []);

  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleDelete = async (taskId) => {
    if (window.confirm('Are you sure you want to delete this task?')) {
      try {
        await deleteTask(taskId);
        setTasks(tasks.filter(task => task.id !== taskId));
        alert('Task deleted successfully');
      } catch (err) {
        console.error('Failed to delete task:', err);
        alert('Failed to delete task. Please try again.');
      }
    }
  };

  const handleStatusChange = async (taskId, newStatus) => {
    try {
      await updateTask(taskId, { status: newStatus });
      setTasks(tasks.map(task =>
        task.id === taskId ? { ...task, status: newStatus } : task
      ));
      alert(`Task marked as ${newStatus}`);
    } catch (err) {
      console.error('Failed to update task status:', err);
      alert('Failed to update task. Please try again.');
    }
  };

//   return (
//     <div className={`dashboard ${isSidebarCollapsed ? "collapsed" : ""}`}>
//       <Sidebar isCollapsed={isSidebarCollapsed} />
//       <div className="main-content">
//         <Header onToggleSidebar={toggleSidebar} />
//         <div className="content">
//           <div className="card-container">
//             <Link to="/all-task" className="card-link">
//             <div className="card cardstyle1">
//               <h3>ALL TASK</h3>
//               <p>22</p>
//             </div>
//             </Link>
//             <Link to="/completed-task" className="card-link">
//             <div className="card cardstyle2">
//               <h3>Completed Tasks</h3>
//               <p>10</p>
//             </div>
//             </Link>
//             <Link to="/panding-task" className="card-link">

//             <div className="card cardstyle3">
//               <h3>Pending Tasks</h3>
//               <p>12</p>
//             </div>
//             </Link>
//           </div>

//           <div className="table-section">
//             <h3>Task List</h3>
//             <table>
//               <thead>
//                 <tr>
//                   <th>#</th>
//                   <th>Task Name</th>
//                   <th>Description</th>
//                   <th>Status</th>
//                   <th>Due Date</th>
//                   <th>Actions</th>
//                 </tr>
//               </thead>
//               <tbody>
//                 <tr>
//                   <td>1</td>
//                   <td>Design Homepage</td>
//                   <td>John Doe</td>
//                   <td>
//                     <span className="status-badge status-completed">
//                       Completed
//                     </span>
//                   </td>
//                   <td>2025-05-10</td>
//                   <td className="action-buttons">
//                     <button>Edit</button>
//                     <button>Delete</button>
//                   </td>
//                 </tr>
//                 <tr>
//                   <td>2</td>
//                   <td>Setup Backend</td>
//                   <td>Jane Smith</td>
//                   <td>
//                     <span className="status-badge status-pending">Pending</span>
//                   </td>
//                   <td>2025-05-12</td>
//                   <td className="action-buttons">
//                     <button>Edit</button>
//                     <button>Delete</button>
//                   </td>
//                 </tr>
//               </tbody>
//             </table>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Dashboard;


return (
  <div className={`dashboard ${isSidebarCollapsed ? "collapsed" : ""}`}>
    <Sidebar isCollapsed={isSidebarCollapsed} />
    <div className="main-content">
      <Header onToggleSidebar={toggleSidebar} />

      {loading ? (
        <div className="loading-container">
          <p>Loading dashboard data...</p>
        </div>
      ) : error ? (
        <div className="error-container">
          <p className="error-message">{error}</p>
          <button onClick={() => window.location.reload()}>Retry</button>
        </div>
      ) : (
        <div className="content">
          <div className="card-container">
            <Link to="/dashboard/all-tasks" className="card-link">
              <div className="card cardstyle1">
                <h3>ALL TASKS</h3>
                <p>{tasks.length}</p>
              </div>
            </Link>
            <Link to="/dashboard/completed-tasks" className="card-link">
              <div className="card cardstyle2">
                <h3>Completed Tasks</h3>
                <p>{completedTasks.length}</p>
              </div>
            </Link>
            <Link to="/dashboard/pending-tasks" className="card-link">
              <div className="card cardstyle3">
                <h3>Pending Tasks</h3>
                <p>{pendingTasks.length}</p>
              </div>
            </Link>
          </div>

          <div className="table-section">
            <div className="table-header">
              <h3>Recent Tasks</h3>
              <Link to="/dashboard/add-task" className="add-task-btn">Add New Task</Link>
            </div>

            {tasks.length === 0 ? (
              <p className="no-tasks-message">No tasks found. Create a new task to get started.</p>
            ) : (
              <table>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Task Name</th>
                    <th>Description</th>
                    <th>Status</th>
                    <th>Due Date</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {tasks.slice(0, 5).map((task, index) => (
                    <tr key={task.id}>
                      <td>{index + 1}</td>
                      <td>{task.title}</td>
                      <td>{task.description}</td>
                      <td>
                        <span className={`status-badge status-${task.status.toLowerCase().replace(' ', '-')}`}>
                          {task.status}
                        </span>
                      </td>
                      <td>{new Date(task.due_date).toLocaleDateString()}</td>
                      <td className="action-buttons">
                        <select
                          onChange={(e) => handleStatusChange(task.id, e.target.value)}
                          value={task.status}
                        >
                          <option value="Pending">Pending</option>
                          <option value="In Progress">In Progress</option>
                          <option value="Completed">Completed</option>
                        </select>
                        <button onClick={() => handleDelete(task.id)}>Delete</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}
    </div>
  </div>
);
};

export default Dashboard;