import React from "react";
import { NavLink, useNavigate } from 'react-router-dom';
import {
  FaHome,
  FaTasks,
  FaPlusCircle,
  FaCheck,
  FaClock,
  FaUser,
  FaCog,
} from "react-icons/fa";
import "../styles/DashboardSlideBar.css";

const DashboardSlideBar = ({ isCollapsed }) => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token"); // Clear JWT token
    navigate("/"); // Redirect to login
  };

  return (
    <div className={`sidebar ${isCollapsed ? "collapsed" : ""}`}>
      <h2 className="logo">{!isCollapsed && "TMS"}</h2>
      <ul className="menu">
        <li>
          <FaHome />
          {!isCollapsed && (
            <span className="menuDashboard">
              <NavLink to="/">Dashboard</NavLink>
            </span>
          )}
        </li>
        <li>
          <FaTasks />
          {!isCollapsed && (
            <span className="menuDashboard">
              <NavLink to="/dashboard/all-tasks">All Tasks</NavLink>
            </span>
          )}
        </li>
        <li>
          <FaCheck />
          {!isCollapsed && (
            <span className="menuDashboard">
              <NavLink to="/dashboard/completed-tasks">Completed Tasks</NavLink>
            </span>
          )}
        </li>
        <li>
          <FaClock />
          {!isCollapsed && (
            <span className="menuDashboard">
              <NavLink to="/dashboard/pending-tasks">Pending Tasks</NavLink>
            </span>
          )}
        </li>
        <li>
          <FaPlusCircle />
          {!isCollapsed && (
            <span className="menuDashboard">
              <NavLink to="/dashboard/add-task">Add Task</NavLink>
            </span>
          )}
        </li>
        <li>
          <FaUser />
          {!isCollapsed && <span>Profile</span>}
        </li>
        <li>
          <FaCog />
          {!isCollapsed && <span>Settings</span>}
        </li>
        <li>
          {!isCollapsed && (
            <button className="logout-btn" onClick={handleLogout}>
              Logout
            </button>
          )}
        </li>
      </ul>
    </div>
  );
};

export default DashboardSlideBar;
