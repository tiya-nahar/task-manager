import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Sidebar from "./DashboardSlideBar";
import Header from "./DashboardHeader";
import "../styles/Profile.css";
import { isTokenValid } from "../utils/api";

const Profile = () => {
  const navigate = useNavigate();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    currentPassword: "",
    newPassword: "",
    confirmPassword: ""
  });
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");

  useEffect(() => {
    // Check if user is authenticated
    if (!isTokenValid()) {
      navigate('/login');
      return;
    }

    // Fetch user data
    const fetchUserData = async () => {
      try {
        setLoading(true);
        
        // Get user from localStorage
        const userStr = localStorage.getItem('user');
        if (!userStr) {
          throw new Error('User data not found');
        }
        
        const userData = JSON.parse(userStr);
        
        // If we need to fetch more user details from the API
        if (userData.email) {
          try {
            const token = localStorage.getItem('token');
            const response = await fetch(`http://localhost:5000/api/auth/user/${userData.email}`, {
              headers: {
                'Authorization': `Bearer ${token}`
              }
            });
            
            if (!response.ok) {
              throw new Error('Failed to fetch user details');
            }
            
            const data = await response.json();
            setUser(data.user);
            setFormData({
              ...formData,
              name: data.user.name || userData.name,
              email: data.user.email || userData.email
            });
          } catch (apiError) {
            console.error('API Error:', apiError);
            // Fallback to using the stored user data
            setUser(userData);
            setFormData({
              ...formData,
              name: userData.name,
              email: userData.email
            });
          }
        } else {
          setUser(userData);
          setFormData({
            ...formData,
            name: userData.name,
            email: userData.email
          });
        }
        
        setError(null);
      } catch (err) {
        console.error('Error loading user data:', err);
        setError('Failed to load user data');
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, [navigate]);

  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleEditToggle = () => {
    setIsEditing(!isEditing);
    setSuccessMessage("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSaving(true);
    setSuccessMessage("");
    
    // Validate passwords if changing password
    if (formData.newPassword) {
      if (formData.newPassword !== formData.confirmPassword) {
        setError("New passwords don't match");
        setIsSaving(false);
        return;
      }
      
      if (!formData.currentPassword) {
        setError("Current password is required to set a new password");
        setIsSaving(false);
        return;
      }
    }
    
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5000/api/auth/update-profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          currentPassword: formData.currentPassword,
          newPassword: formData.newPassword || undefined
        })
      });
      
      const data = await response.json();
      
      if (response.ok) {
        // Update local storage with new user data
        const updatedUser = {
          ...user,
          name: formData.name,
          email: formData.email
        };
        
        localStorage.setItem('user', JSON.stringify(updatedUser));
        setUser(updatedUser);
        setSuccessMessage("Profile updated successfully!");
        setIsEditing(false);
        
        // Clear password fields
        setFormData({
          ...formData,
          currentPassword: "",
          newPassword: "",
          confirmPassword: ""
        });
      } else {
        setError(data.message || "Failed to update profile");
      }
    } catch (err) {
      console.error('Error updating profile:', err);
      setError("An error occurred while updating your profile");
    } finally {
      setIsSaving(false);
    }
  };

  if (loading) {
    return (
      <div className={`dashboard ${isSidebarCollapsed ? "collapsed" : ""}`}>
        <Sidebar isCollapsed={isSidebarCollapsed} />
        <div className="main-content">
          <Header onToggleSidebar={toggleSidebar} />
          <div className="loading-container">
            <p>Loading profile data...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`dashboard ${isSidebarCollapsed ? "collapsed" : ""}`}>
      <Sidebar isCollapsed={isSidebarCollapsed} />
      <div className="main-content">
        <Header onToggleSidebar={toggleSidebar} />
        
        <div className="profile-container">
          <div className="profile-header">
            <h2>My Profile</h2>
            <button 
              className={`edit-button ${isEditing ? 'cancel' : ''}`} 
              onClick={handleEditToggle}
            >
              {isEditing ? 'Cancel' : 'Edit Profile'}
            </button>
          </div>
          
          {error && <div className="error-message">{error}</div>}
          {successMessage && <div className="success-message">{successMessage}</div>}
          
          <div className="profile-content">
            <div className="profile-avatar">
              <img src="/profile.png" alt="Profile" />
              {isEditing && (
                <div className="avatar-upload">
                  <label htmlFor="avatar-input">Change Photo</label>
                  <input 
                    type="file" 
                    id="avatar-input" 
                    accept="image/*" 
                    disabled={true} // Disabled for now as we're not implementing file upload
                  />
                </div>
              )}
            </div>
            
            <div className="profile-details">
              {isEditing ? (
                <form onSubmit={handleSubmit}>
                  <div className="form-group">
                    <label>Name</label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  
                  <div className="form-group">
                    <label>Email</label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  
                  <div className="password-section">
                    <h3>Change Password</h3>
                    <div className="form-group">
                      <label>Current Password</label>
                      <input
                        type="password"
                        name="currentPassword"
                        value={formData.currentPassword}
                        onChange={handleChange}
                      />
                    </div>
                    
                    <div className="form-group">
                      <label>New Password</label>
                      <input
                        type="password"
                        name="newPassword"
                        value={formData.newPassword}
                        onChange={handleChange}
                      />
                    </div>
                    
                    <div className="form-group">
                      <label>Confirm New Password</label>
                      <input
                        type="password"
                        name="confirmPassword"
                        value={formData.confirmPassword}
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                  
                  <button 
                    type="submit" 
                    className="save-button"
                    disabled={isSaving}
                  >
                    {isSaving ? 'Saving...' : 'Save Changes'}
                  </button>
                </form>
              ) : (
                <div className="profile-info">
                  <div className="info-group">
                    <span className="label">Name:</span>
                    <span className="value">{user?.name || 'N/A'}</span>
                  </div>
                  
                  <div className="info-group">
                    <span className="label">Email:</span>
                    <span className="value">{user?.email || 'N/A'}</span>
                  </div>
                  
                  <div className="info-group">
                    <span className="label">Member Since:</span>
                    <span className="value">
                      {user?.created_at 
                        ? new Date(user.created_at).toLocaleDateString() 
                        : 'N/A'}
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
