import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/Auth.css';

const AuthPage = ({ onLogin, isSignUp: initialIsSignUp }) => {
    const navigate = useNavigate();
    const [isSignUp, setIsSignUp] = useState(initialIsSignUp || false);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);

    // Form state
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        password: ''
    });

    // Check if user is already logged in and update form based on initialIsSignUp
    useEffect(() => {
        // Update isSignUp state if prop changes
        if (initialIsSignUp !== undefined) {
            setIsSignUp(initialIsSignUp);
        }

        // Check if user is already logged in
        const token = localStorage.getItem('token');
        if (token) {
            navigate('/dashboard');
        }
    }, [navigate, initialIsSignUp]);

    const handleSignUpClick = () => {
        setIsSignUp(true);
        setFormData({ name: '', email: '', password: '' });  // Reset form
        setError(null);
    };

    const handleSignInClick = () => {
        setIsSignUp(false);
        setFormData({ name: '', email: '', password: '' });  // Reset form
        setError(null);
    };

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsLoading(true);
        setError(null);

        try {
            const endpoint = isSignUp ? 'register' : 'login';
            const payload = isSignUp
                ? { name: formData.name, email: formData.email, password: formData.password }
                : { email: formData.email, password: formData.password };

            const response = await fetch(`http://localhost:5000/api/auth/${endpoint}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(payload)
            });

            const data = await response.json();

            if (response.ok) {
                // Store token and user data
                localStorage.setItem('token', data.token);
                localStorage.setItem('user', JSON.stringify(data.user));

                console.log(`✅ ${isSignUp ? 'Registered' : 'Login'} successful:`, data);

                if (onLogin) {
                    onLogin();
                }

                // Redirect to dashboard
                navigate('/dashboard');
            } else {
                console.error(`❌ ${isSignUp ? 'Register' : 'Login'} error:`, data.message || data.error);
                setError(data.message || `${isSignUp ? 'Registration' : 'Login'} failed`);
            }
        } catch (error) {
            console.error('❌ Network error:', error);
            setError('Network error. Please check your connection and try again.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="auth-page">
            <div className={`container ${isSignUp ? 'right-panel-active' : ''}`} id="container">
                <div className="form-container sign-up-container">
                    <form onSubmit={handleSubmit}>
                        <h1 className="auth-heading">Create Account</h1>
                        <div className="social-container">
                            <a href="#" className="social"><i className="fab fa-facebook-f"></i></a>
                            <a href="#" className="social"><i className="fab fa-google-plus-g"></i></a>
                            <a href="#" className="social"><i className="fab fa-linkedin-in"></i></a>
                        </div>
                        <span className="auth-span">or use your email for registration</span>
                        {error && <div className="error-message">{error}</div>}
                        <input
                            type="text"
                            placeholder="Name"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            required
                            disabled={isLoading}
                        />
                        <input
                            type="email"
                            placeholder="Email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            required
                            disabled={isLoading}
                        />
                        <input
                            type="password"
                            placeholder="Password"
                            name="password"
                            value={formData.password}
                            onChange={handleChange}
                            required
                            disabled={isLoading}
                        />
                        <button type="submit" disabled={isLoading}>
                            {isLoading ? 'Processing...' : 'Sign Up'}
                        </button>
                        <div className="mobile-toggle">
                            Already have an account? <button type="button" onClick={handleSignInClick}>Sign In</button>
                        </div>
                    </form>
                </div>
                <div className="form-container sign-in-container">
                    <form onSubmit={handleSubmit}>
                        <h1 className="auth-heading">Sign in</h1>
                        <div className="social-container">
                            <a href="#" className="social"><i className="fab fa-facebook-f"></i></a>
                            <a href="#" className="social"><i className="fab fa-google-plus-g"></i></a>
                            <a href="#" className="social"><i className="fab fa-linkedin-in"></i></a>
                        </div>
                        <span className="auth-span">or use your account</span>
                        {error && <div className="error-message">{error}</div>}
                        <input
                            type="email"
                            placeholder="Email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            required
                            disabled={isLoading}
                        />
                        <input
                            type="password"
                            placeholder="Password"
                            name="password"
                            value={formData.password}
                            onChange={handleChange}
                            required
                            disabled={isLoading}
                        />
                        <a href="#" className="forgot-link">Forgot your password?</a>
                        <button type="submit" disabled={isLoading}>
                            {isLoading ? 'Processing...' : 'Sign In'}
                        </button>
                        <div className="mobile-toggle">
                            Don't have an account? <button type="button" onClick={handleSignUpClick}>Sign Up</button>
                        </div>
                    </form>
                </div>
                <div className="overlay-container">
                    <div className="overlay">
                        <div className="overlay-panel overlay-left">
                            <h1 className="auth-heading">Welcome Back!</h1>
                            <p className="auth-paragraph">To keep connected with us please login with your personal info</p>
                            <button className="ghost" onClick={handleSignInClick}>Sign In</button>
                        </div>
                        <div className="overlay-panel overlay-right">
                            <h1 className="auth-heading">Hello, Friend!</h1>
                            <p className="auth-paragraph">Enter your personal details and start journey with us</p>
                            <button className="ghost" onClick={handleSignUpClick}>Sign Up</button>
                        </div>
                    </div>
                </div>
            </div>
            <footer className="auth-footer">
                {/* Optional footer content */}
            </footer>
        </div>

    );

};

export default AuthPage;
