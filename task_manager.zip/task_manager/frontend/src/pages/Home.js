import React, { useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { isTokenValid } from '../utils/api';
import '../styles/Home.css';

const Home = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // If user is already logged in, redirect to dashboard
    if (isTokenValid()) {
      navigate('/dashboard');
    }
  }, [navigate]);

  return (
    <div className="home-container">
      <div className="home-content">
        <h1>Welcome to Task Manager</h1>
        <p>Organize your tasks efficiently and boost your productivity</p>
        
        <div className="home-buttons">
          <Link to="/login" className="home-button login">
            Login
          </Link>
          <Link to="/signup" className="home-button signup">
            Sign Up
          </Link>
        </div>
        
        <div className="home-features">
          <div className="feature">
            <div className="feature-icon">📋</div>
            <h3>Task Organization</h3>
            <p>Organize tasks by priority, due date, and status</p>
          </div>
          
          <div className="feature">
            <div className="feature-icon">🔔</div>
            <h3>Reminders</h3>
            <p>Never miss a deadline with timely reminders</p>
          </div>
          
          <div className="feature">
            <div className="feature-icon">📊</div>
            <h3>Progress Tracking</h3>
            <p>Track your productivity and task completion</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
