import React, { useState, useEffect } from 'react';
import Sidebar from './DashboardSlideBar';
import Header from './DashboardHeader';
import '../styles/AddTask.css';
import { useNavigate } from 'react-router-dom';
import { createTask, isTokenValid, getUserIdFromToken } from '../utils/api';

const AddTask = () => {
    const navigate = useNavigate();

    const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [dueDate, setDueDate] = useState('');
    const [priority, setPriority] = useState('Medium');
    const [isSubmitting, setIsSubmitting] = useState(false);

    useEffect(() => {
        // Check if user is authenticated
        if (!isTokenValid()) {
            navigate('/login');
        }
    }, [navigate]);

    const toggleSidebar = () => {
        setIsSidebarCollapsed(!isSidebarCollapsed);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!isTokenValid()) {
            alert('Session expired. Please login again.');
            navigate('/login');
            return;
        }

        setIsSubmitting(true);

        const userId = getUserIdFromToken();

        const newTask = {
            title,
            description,
            due_date: dueDate,
            priority,
            status: 'Pending',
            assigned_to: userId
        };

        try {
            const result = await createTask(newTask);
            console.log('✅ Task added:', result);
            alert('Task created successfully!');
            navigate('/dashboard/all-tasks');
        } catch (error) {
            console.error('❌ Error:', error);
            alert(error.message || 'Failed to add task');
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className={`dashboard ${isSidebarCollapsed ? 'collapsed' : ''}`}>
            <Sidebar isCollapsed={isSidebarCollapsed} />
            <div className="main-content">
                <Header onToggleSidebar={toggleSidebar} />
                <div className="content">
                    <div className="add-task-container">
                        <h2>Create New Task</h2>
                        <form onSubmit={handleSubmit}>
                            <input className='inputField'
                                type="text"
                                placeholder="Title"
                                value={title}
                                onChange={(e) => setTitle(e.target.value)}
                                required
                            />
                            <textarea className='inputField'
                                placeholder="Description"
                                value={description}
                                onChange={(e) => setDescription(e.target.value)}
                            />
                            <input
                                type="date"
                                value={dueDate}
                                onChange={(e) => setDueDate(e.target.value)}
                            />
                            <select className='inputField'
                                value={priority}
                                onChange={(e) => setPriority(e.target.value)}
                            >
                                <option value="Low">Low</option>
                                <option value="Medium">Medium</option>
                                <option value="High">High</option>
                            </select>
                            <button type="submit" disabled={isSubmitting}>
                                {isSubmitting ? 'Creating...' : 'Add Task'}
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AddTask;
