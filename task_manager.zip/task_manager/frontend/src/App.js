import React, { useState, useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import AuthPage from './pages/Auth';
import Dashboard from './pages/Dashboard';
import AddTask from './pages/AddTask';
import CompletedTasks from './pages/CompletedTask';
import PendingTask from './pages/PendingTask';
import AllTasks from './pages/AllTask';
import Profile from './pages/Profile';
import Settings from './pages/Settings';
import Home from './pages/Home';
import { isTokenValid } from './utils/api';

// Import styles
import './styles/responsive.css';

// Protected Route component
const ProtectedRoute = ({ children }) => {
  const isAuthenticated = isTokenValid();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return children;
};

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    // Check if user is logged in on app load
    const checkAuth = () => {
      const authenticated = isTokenValid();
      setIsLoggedIn(authenticated);
    };

    checkAuth();

    // Set up an interval to periodically check token validity
    const interval = setInterval(checkAuth, 60000); // Check every minute

    return () => clearInterval(interval);
  }, []);

  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<AuthPage onLogin={() => setIsLoggedIn(true)} />} />
      <Route path="/signup" element={<AuthPage isSignUp={true} onLogin={() => setIsLoggedIn(true)} />} />
      <Route path="/dashboard" element={
        <ProtectedRoute>
          <Dashboard />
        </ProtectedRoute>
      } />

      <Route path="/dashboard/add-task" element={
        <ProtectedRoute>
          <AddTask />
        </ProtectedRoute>
      } />

      <Route path="/dashboard/completed-tasks" element={
        <ProtectedRoute>
          <CompletedTasks />
        </ProtectedRoute>
      } />

      <Route path="/dashboard/pending-tasks" element={
        <ProtectedRoute>
          <PendingTask />
        </ProtectedRoute>
      } />

      <Route path="/dashboard/all-tasks" element={
        <ProtectedRoute>
          <AllTasks />
        </ProtectedRoute>
      } />

      <Route path="/dashboard/profile" element={
        <ProtectedRoute>
          <Profile />
        </ProtectedRoute>
      } />

      <Route path="/dashboard/settings" element={
        <ProtectedRoute>
          <Settings />
        </ProtectedRoute>
      } />

      {/* Redirect to dashboard if logged in, otherwise to home */}
      <Route path="*" element={isLoggedIn ? <Navigate to="/dashboard" /> : <Navigate to="/" />} />
    </Routes>
  );
}

export default App;
