import { jwtDecode } from 'jwt-decode';

const API_URL = 'http://localhost:5000/api';

// Helper function to check if token is valid
export const isTokenValid = () => {
  const token = localStorage.getItem('token');
  if (!token) return false;
  
  try {
    const decoded = jwtDecode(token);
    const currentTime = Date.now() / 1000;
    return decoded.exp > currentTime;
  } catch (error) {
    console.error('Error decoding token:', error);
    return false;
  }
};

// Get user ID from token
export const getUserIdFromToken = () => {
  const token = localStorage.getItem('token');
  if (!token) return null;
  
  try {
    const decoded = jwtDecode(token);
    return decoded.userId;
  } catch (error) {
    console.error('Error decoding token:', error);
    return null;
  }
};

// Generic API request function
export const apiRequest = async (endpoint, method = 'GET', data = null) => {
  const token = localStorage.getItem('token');
  
  if (!token) {
    throw new Error('No authentication token found');
  }
  
  const headers = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
  };
  
  const config = {
    method,
    headers
  };
  
  if (data && (method === 'POST' || method === 'PUT')) {
    config.body = JSON.stringify(data);
  }
  
  try {
    const response = await fetch(`${API_URL}${endpoint}`, config);
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || errorData.error || 'API request failed');
    }
    
    return await response.json();
  } catch (error) {
    console.error('API request error:', error);
    throw error;
  }
};

// Task-specific API functions
export const fetchAllTasks = async () => {
  return apiRequest('/tasks');
};

export const fetchUserTasks = async () => {
  return apiRequest('/tasks/user');
};

export const fetchTaskById = async (taskId) => {
  return apiRequest(`/tasks/${taskId}`);
};

export const createTask = async (taskData) => {
  return apiRequest('/tasks', 'POST', taskData);
};

export const updateTask = async (taskId, taskData) => {
  return apiRequest(`/tasks/${taskId}`, 'PUT', taskData);
};

export const deleteTask = async (taskId) => {
  return apiRequest(`/tasks/${taskId}`, 'DELETE');
};

// Filtered task functions
export const fetchCompletedTasks = async () => {
  const tasks = await fetchUserTasks();
  return tasks.filter(task => task.status === 'Completed');
};

export const fetchPendingTasks = async () => {
  const tasks = await fetchUserTasks();
  return tasks.filter(task => task.status === 'Pending');
};

export const fetchInProgressTasks = async () => {
  const tasks = await fetchUserTasks();
  return tasks.filter(task => task.status === 'In Progress');
};
