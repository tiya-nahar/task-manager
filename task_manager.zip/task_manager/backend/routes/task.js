const express = require('express');
const router = express.Router();
const pool = require('../db');
const authenticateToken = require('../middleware/auth');

/**
 * @route   GET /api/tasks
 * @desc    Get all tasks
 * @access  Private
 */
router.get('/', authenticateToken, async (_req, res) => {
  try {
    const result = await pool.query(
      `SELECT * FROM tasks ORDER BY due_date ASC`
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   GET /api/tasks/user
 * @desc    Get tasks for current user (created by or assigned to)
 * @access  Private
 */
router.get('/user', authenticateToken, async (req, res) => {
  const userId = req.user.userId;

  try {
    const result = await pool.query(
      `SELECT * FROM tasks
       WHERE created_by = $1 OR assigned_to = $1
       ORDER BY due_date ASC`,
      [userId]
    );

    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   GET /api/tasks/:id
 * @desc    Get a task by ID
 * @access  Private
 */
router.get('/:id', authenticateToken, async (req, res) => {
  const taskId = req.params.id;

  try {
    const result = await pool.query(
      `SELECT * FROM tasks WHERE id = $1`,
      [taskId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Task not found' });
    }

    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   POST /api/tasks
 * @desc    Create a new task
 * @access  Private
 */
router.post('/', authenticateToken, async (req, res) => {
  const { title, description, due_date, priority, status, assigned_to } = req.body;
  const created_by = req.user.userId;

  if (!title || !description || !due_date || !priority || !status || !assigned_to) {
    return res.status(400).json({ error: 'All fields must be provided' });
  }

  try {
    const result = await pool.query(
      `INSERT INTO tasks (title, description, due_date, priority, status, assigned_to, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
      [title, description, due_date, priority, status, assigned_to, created_by]
    );

    res.status(201).json({ message: 'Task created successfully', task: result.rows[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   PUT /api/tasks/:id
 * @desc    Update a task
 * @access  Private
 */
router.put('/:id', authenticateToken, async (req, res) => {
  const taskId = req.params.id;
  const { title, description, due_date, priority, status, assigned_to } = req.body;
  try {
    // Check if task exists
    const taskCheck = await pool.query(
      `SELECT * FROM tasks WHERE id = $1`,
      [taskId]
    );

    if (taskCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Task not found' });
    }

    // Optional: Add permission check if needed
    // if (taskCheck.rows[0].created_by !== userId) {
    //   return res.status(403).json({ error: 'Not authorized to update this task' });
    // }

    const result = await pool.query(
      `UPDATE tasks SET
        title = COALESCE($1, title),
        description = COALESCE($2, description),
        due_date = COALESCE($3, due_date),
        priority = COALESCE($4, priority),
        status = COALESCE($5, status),
        assigned_to = COALESCE($6, assigned_to)
       WHERE id = $7
       RETURNING *`,
      [title, description, due_date, priority, status, assigned_to, taskId]
    );

    res.json({ message: 'Task updated successfully', task: result.rows[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * @route   DELETE /api/tasks/:id
 * @desc    Delete a task
 * @access  Private
 */
router.delete('/:id', authenticateToken, async (req, res) => {
  const taskId = req.params.id;
  try {
    // Check if task exists
    const taskCheck = await pool.query(
      `SELECT * FROM tasks WHERE id = $1`,
      [taskId]
    );

    if (taskCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Task not found' });
    }

    // Optional: Add permission check if needed
    // if (taskCheck.rows[0].created_by !== userId) {
    //   return res.status(403).json({ error: 'Not authorized to delete this task' });
    // }

    await pool.query('DELETE FROM tasks WHERE id = $1', [taskId]);
    res.json({ message: 'Task deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
