require('dotenv').config();
const axios = require('axios');

// Base URL for API requests
const API_URL = 'http://localhost:5000/api';

// Test user credentials
const testUser = {
  email: 'test@example.com',
  password: 'password123'
};

// Store the JWT token
let token = '';

// Helper function to make authenticated requests
const authRequest = async (method, endpoint, data = null) => {
  const config = {
    headers: { Authorization: `Bearer ${token}` }
  };

  try {
    let response;
    if (method === 'get') {
      response = await axios.get(`${API_URL}${endpoint}`, config);
    } else if (method === 'post') {
      response = await axios.post(`${API_URL}${endpoint}`, data, config);
    } else if (method === 'put') {
      response = await axios.put(`${API_URL}${endpoint}`, data, config);
    } else if (method === 'delete') {
      response = await axios.delete(`${API_URL}${endpoint}`, config);
    }
    return response.data;
  } catch (error) {
    console.error('Error:', error.response ? error.response.data : error.message);
    return null;
  }
};

// Login and get token
const login = async () => {
  try {
    const response = await axios.post(`${API_URL}/auth/login`, testUser);
    token = response.data.token;
    console.log('Login successful, token received');
    return true;
  } catch (error) {
    console.error('Login failed:', error.response ? error.response.data : error.message);
    return false;
  }
};

// Test creating a task
const testCreateTask = async () => {
  const newTask = {
    title: 'Test Task',
    description: 'This is a test task created via API',
    due_date: '2023-12-31',
    priority: 'High',
    status: 'Pending',
    assigned_to: 1 // Assuming user ID 1 exists
  };

  console.log('Testing task creation...');
  const result = await authRequest('post', '/tasks', newTask);
  
  if (result && result.task) {
    console.log('Task created successfully:', result.task.id);
    return result.task.id;
  } else {
    console.log('Task creation failed');
    return null;
  }
};

// Test getting all tasks
const testGetAllTasks = async () => {
  console.log('Testing get all tasks...');
  const result = await authRequest('get', '/tasks');
  
  if (result) {
    console.log(`Retrieved ${result.length} tasks`);
    return true;
  } else {
    console.log('Failed to retrieve tasks');
    return false;
  }
};

// Test getting a single task
const testGetTask = async (taskId) => {
  console.log(`Testing get task with ID ${taskId}...`);
  const result = await authRequest('get', `/tasks/${taskId}`);
  
  if (result && result.id) {
    console.log('Task retrieved successfully:', result.title);
    return true;
  } else {
    console.log('Failed to retrieve task');
    return false;
  }
};

// Test updating a task
const testUpdateTask = async (taskId) => {
  const updateData = {
    title: 'Updated Test Task',
    status: 'In Progress'
  };

  console.log(`Testing update task with ID ${taskId}...`);
  const result = await authRequest('put', `/tasks/${taskId}`, updateData);
  
  if (result && result.message) {
    console.log('Task updated successfully');
    return true;
  } else {
    console.log('Failed to update task');
    return false;
  }
};

// Test deleting a task
const testDeleteTask = async (taskId) => {
  console.log(`Testing delete task with ID ${taskId}...`);
  const result = await authRequest('delete', `/tasks/${taskId}`);
  
  if (result && result.message) {
    console.log('Task deleted successfully');
    return true;
  } else {
    console.log('Failed to delete task');
    return false;
  }
};

// Run all tests
const runTests = async () => {
  console.log('Starting API tests...');
  
  // Login first
  const loginSuccess = await login();
  if (!loginSuccess) {
    console.log('Tests aborted due to login failure');
    return;
  }
  
  // Create a task
  const taskId = await testCreateTask();
  if (!taskId) {
    console.log('Tests aborted due to task creation failure');
    return;
  }
  
  // Get all tasks
  await testGetAllTasks();
  
  // Get the specific task
  await testGetTask(taskId);
  
  // Update the task
  await testUpdateTask(taskId);
  
  // Delete the task
  await testDeleteTask(taskId);
  
  console.log('All tests completed');
};

// Run the tests
runTests();
